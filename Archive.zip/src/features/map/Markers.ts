export interface Markers {
  id: string;
  title: string;
  body: string;
  lat: string;
  lng: string;
  url: string;
  category: string;
}
