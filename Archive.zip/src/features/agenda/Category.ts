export interface Category {
  name: string;
  check: boolean;
}
