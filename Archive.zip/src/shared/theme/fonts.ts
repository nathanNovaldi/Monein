/* @flow */

export const fonts = {
  regular: 'RobotoCondensed-Regular',
  semiBold: 'Montserrat-SemiBold',
  semiBoldItalic: 'Montserrat-SemiBoldItalic',
  italic: 'RobotoCondensed-Italic',
  bold: 'RobotoCondensed-Bold',
  awesome: 'Awesome',
};
