export const colors = {
  mainColor: '#f54446',
  secondaryColor: '#F78F91',
  background: '#ebedf2',
  textDark: 'black',
  textLight: 'white',
  mainMarker: '#e94649',
  secondaryMarker: '#494848',
  lightGrey: '#B7B7BD',
  darkGrey: '#767380',
  navBarColor: '#OOO',
  navBarIconColor: '#1c7269',
  btn_background: '#FFF',
};
