export default {
  home: {
    title: 'Accueil',
  },
};
