export const colors = {
  navBarColor: '#FFF',
  navBarIconColor: '#1c7269',
  mainColor: '#1c7269',
  secondaryColor: '#F78F91',
  background: '#FFF',
  btn_background: '#FFF',
  textDark: 'black',
  textLight: 'white',
  mainMarker: '#e94649',
  secondaryMarker: '#494848',
  lightGrey: '#B7B7BD',
  darkGrey: '#767380',
};
